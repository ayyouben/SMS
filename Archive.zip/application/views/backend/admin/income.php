<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/ic.png"  alt="" />
	      
           
</div>