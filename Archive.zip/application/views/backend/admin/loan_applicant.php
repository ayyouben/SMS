<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/loan.png"  alt="" />
	      
           
</div>