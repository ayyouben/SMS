<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/tid.png"  alt="" />
	      
           
</div>